##begins here

''' 
    suhffle and split the data set to 5 folds
    where each fold contains 100 samples
'''


'''
    train linear regression models using the following setup:
    seperate fold i as test and train a model on the remaining
    folds. in the end, you should have trained 5 models, one
    per test fold.
    --- for each model calculate R^2, mean squared error, 
        mean absolute error, and mean absolute percentage error.
'''