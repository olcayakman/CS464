# HOW TO COMPILE AND RUN THE HOMEWORK.
each question can be run with python3
